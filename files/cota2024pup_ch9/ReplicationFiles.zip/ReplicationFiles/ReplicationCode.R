# File name: ReplicationCode.R

# Author: Matt Cota

# Creation Date: 3/21/2024

# Last Edited: 3/21/2024

# Purpose: Replication code for Cota, Matthew T. 2024. "Speaking Off the Bench: Analyzing the Extrajudicial Appearances of Supreme Court Justices." in Robert X. Browning, ed., Partisan Rhetoric and Polarization: The Year in C-SPAN Archives Research, Volume 10. Purdue University Press.

# Libraries
library(tidyverse)
library(broom)
library(patchwork)
library(reshape2)

#######################
#######################
#######################
### BEGIN CODE USED ###
#######################
#######################
#######################

# Read in data
df = read.csv("C:/Users/mtc/Dropbox/mtc/lab/sub lab/pubs/cota2024pup_ch9/ReplicationData.csv")

##############################
### Regressions and Tables ###
##############################

###
### Tables 9.1 and 9.3 
###

### Masculine Language ###
MasLang_mod = df %>%
  nest_by(justiceName) %>%
  mutate(MasLang_mod = list(lm(rateMaleWords ~ speechType + audienceType, data = data))) %>%
  reframe(tidy(MasLang_mod)) 
MasLang_mod$outcome = "Masculine Language"

### Feminine Language ###
FemLang_mod = df %>%
  nest_by(justiceName) %>%
  mutate(FemLang_mod = list(lm(rateFemWords ~ speechType + audienceType, data = data))) %>%
  reframe(tidy(FemLang_mod))
FemLang_mod$outcome = "Feminine Language"



###
### Tables 9.2 and 9.4 
###

### Emotional Language ###
EmoLang_mod = df %>%
  nest_by(justiceName) %>%
  mutate(EmoLang_mod = list(lm(Affect ~ speechType + audienceType, data = data))) %>%
  reframe(tidy(EmoLang_mod)) 
EmoLang_mod$outcome = "Emotional Language"

### Political Language ###
PolLang_mod = df %>%
  nest_by(justiceName) %>%
  mutate(PolLang_mod = list(lm(politic ~ speechType + audienceType, data = data))) %>%
  reframe(tidy(PolLang_mod)) 
PolLang_mod$outcome = "Political Language"

### Cognitive Language ###
CogLang_mod = df %>%
  nest_by(justiceName) %>%
  mutate(CogLang_mod = list(lm(Cognition ~ speechType + audienceType, data = data))) %>%
  reframe(tidy(CogLang_mod)) 
CogLang_mod$outcome = "Cognitive Language"

### Drives ###
DriLang_mod = df %>%
  nest_by(justiceName) %>%
  mutate(DriLang_mod = list(lm(Drives ~ speechType + audienceType, data = data))) %>%
  reframe(tidy(DriLang_mod)) 
DriLang_mod$outcome = "Drives"


###############
### Figures ###
###############

# Bind model outputs into a datafrane
mod_df = bind_rows(EmoLang_mod, PolLang_mod, CogLang_mod, DriLang_mod, MasLang_mod, FemLang_mod)
rm(EmoLang_mod, PolLang_mod, CogLang_mod, DriLang_mod, MasLang_mod, FemLang_mod)

# Create confidence intervals and denote statistical significance
mod_df$upper = mod_df$estimate + 1.96*mod_df$std.error
mod_df$lower = mod_df$estimate - 1.96*mod_df$std.error
mod_df$sig = mod_df$upper < 0 | mod_df$lower > 0

# Add the justices' full names for plotting
mod_df$justiceRealName = mod_df$justiceName
mod_df$justiceRealName[mod_df$justiceRealName == 'WHRehnquist'] = 'William H. Rehnquist'
mod_df$justiceRealName[mod_df$justiceRealName == 'JPStevens'] = 'John Paul Stevens'
mod_df$justiceRealName[mod_df$justiceRealName == "SDOConnor"] = "Sandra Day O'Connor"
mod_df$justiceRealName[mod_df$justiceRealName == 'AScalia'] = 'Antonin Scalia'
mod_df$justiceRealName[mod_df$justiceRealName == 'AMKennedy'] = 'Anthony M. Kennedy'
mod_df$justiceRealName[mod_df$justiceRealName == 'DHSouter'] = 'David H. Souter'
mod_df$justiceRealName[mod_df$justiceRealName == 'CThomas'] = 'Clarence Thomas'
mod_df$justiceRealName[mod_df$justiceRealName == 'RBGinsburg'] = 'Ruth Bader Ginsburg'
mod_df$justiceRealName[mod_df$justiceRealName == 'SGBreyer'] = 'Stephen G. Breyer'
mod_df$justiceRealName[mod_df$justiceRealName == 'JGRoberts'] = 'John G. Roberts'
mod_df$justiceRealName[mod_df$justiceRealName == 'SAAlito'] = 'Samuel A. Alito'
mod_df$justiceRealName[mod_df$justiceRealName == 'SMSotomayor'] = 'Sonia M. Sotomayor'
mod_df$justiceRealName[mod_df$justiceRealName =='EKagan'] = 'Elena Kagan'
mod_df$justiceRealName[mod_df$justiceRealName =='NMGorsuch'] = 'Neil M. Gorsuch'



###
### Figure 9.2a
###

ggplot(subset(mod_df, outcome == "Feminine Language"),
       aes(x = reorder(justiceRealName, estimate), 
           y = estimate,
           color=sig)) +  # Map 'sig' to color
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), size = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = "Change in Rate of Masculine Language per 1000 words Moving from Oral Argument to Public Remarks",
       x = NULL) +
  theme(legend.position = "bottom") +
  theme(axis.text.y = element_text(size = 12, vjust = 0.3)) +
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 10),
        axis.text.x = element_text(size=12)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.2b
###

ggplot(subset(mod_df, outcome == "Masculine Language"),
       aes(x = reorder(justiceRealName, estimate), 
           y = estimate,
           color=sig)) +  # Map 'sig' to color
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), size = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = "Change in Rate of Masculine Language per 1000 words Moving from Oral Argument to Public Remarks",
       x = NULL) +
  theme(legend.position = "bottom") +
  theme(axis.text.y = element_text(size = 12, vjust = 0.3)) +
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 10),
        axis.text.x = element_text(size=12)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.3a (top)
###

ggplot(subset(mod_df, outcome == "Emotional Language"),
       aes(x = reorder(justiceRealName, estimate), 
           y = estimate,
           color = sig)) +
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin = lower, ymax = upper), width = 0, position = position_dodge(width = 0.4), linewidth = 1) +
  geom_hline(yintercept = 0, linetype = 2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom', legend.justification = 'center') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) +
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.3a (bottom)
###

ggplot(subset(mod_df, outcome == "Drives"),
       aes(x = reorder(justiceRealName, estimate), 
           y = estimate,
           color = sig)) +
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), linewidth = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom', legend.justification = 'center') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) +
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.3b (top)
###

ggplot(subset(mod_df, outcome == "Cognitive Language"),
       aes(x = reorder(justiceRealName, estimate), 
           y = estimate,
           color = sig)) +
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), linewidth = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("black", "grey"),
                     labels=c('False', 'True'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = "bottom", legend.justification = "center") +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) +
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))

###
### Figure 9.3b (bottom)
###

ggplot(subset(mod_df, outcome == "Political Language"),
       aes(x = reorder(justiceRealName, estimate), 
           y = estimate,
           color = sig)) +
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), linewidth = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom', legend.justification = 'center') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) +
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))


###
### Figure 9.1a
###

# Subset data
fig91ab = df[c('justiceName', 'speechType', 'totMaleWords', 'totFemWords', 'WC', 'Affect', 'politic', 'Cognition', 'Drives')]

# Word counts per category
fig91ab$affectPercent = fig91ab$Affect / 100
fig91ab$affectWC = fig91ab$affectPercent * fig91ab$WC
fig91ab$politicPercent = fig91ab$politic / 100
fig91ab$politicWC = fig91ab$politicPercent * fig91ab$WC
fig91ab$cognitionPercent = fig91ab$Cognition / 100
fig91ab$cognitionWC = fig91ab$cognitionPercent * fig91ab$WC
fig91ab$drivesPercent = fig91ab$Drives / 100
fig91ab$DrivesWC = fig91ab$drivesPercent * fig91ab$WC

# Sums of words by justice and speech type
fig91ab = fig91ab %>%
  group_by(justiceName, speechType) %>%
  mutate(sumFem = sum(totFemWords),
         sumMas = sum(totFemWords),
         sumAffect = sum(affectWC),
         sumPolitic = sum(politicWC),
         sumCognition = sum(cognitionWC),
         sumDrive = sum(DrivesWC),
         sumWC = sum(WC)) %>%
  mutate(sumFem = floor(sumFem),
         sumMas = floor(sumMas),
         sumAffect = floor(sumAffect),
         sumPolitic = floor(sumPolitic),
         sumCognition = floor(sumCognition),
         sumDrive = floor(sumDrive)) %>%
  select(speechType, justiceName, sumFem, sumMas, sumAffect, sumPolitic, sumCognition, sumDrive, sumWC) 
fig91ab = unique(fig91ab)

# Sort data
fig91ab = melt(fig91ab, id.vars = c("justiceName", "speechType", 'sumWC'))

# Add the justices' full names for plotting
fig91ab$justiceRealName = fig91ab$justiceName
fig91ab$justiceRealName[fig91ab$justiceRealName == 'WHRehnquist'] = 'William H. Rehnquist'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'JPStevens'] = 'John Paul Stevens'
fig91ab$justiceRealName[fig91ab$justiceRealName == "SDOConnor"] = "Sandra Day O'Connor"
fig91ab$justiceRealName[fig91ab$justiceRealName == 'AScalia'] = 'Antonin Scalia'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'AMKennedy'] = 'Anthony M. Kennedy'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'DHSouter'] = 'David H. Souter'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'CThomas'] = 'Clarence Thomas'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'RBGinsburg'] = 'Ruth Bader Ginsburg'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'SGBreyer'] = 'Stephen G. Breyer'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'JGRoberts'] = 'John G. Roberts'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'SAAlito'] = 'Samuel A. Alito'
fig91ab$justiceRealName[fig91ab$justiceRealName == 'SMSotomayor'] = 'Sonia M. Sotomayor'
fig91ab$justiceRealName[fig91ab$justiceRealName =='EKagan'] = 'Elena Kagan'
fig91ab$justiceRealName[fig91ab$justiceRealName =='NMGorsuch'] = 'Neil M. Gorsuch'
fig91ab$speechType[fig91ab$speechType == 'publicRemarks'] = 'Public Remarks'
fig91ab$speechType[fig91ab$speechType =='oralArgument'] = 'Oral Argument'

# Percentages for each type of linguistic category
fig91ab$pcent = fig91ab$value / fig91ab$sumWC * 100
fig91ab$pcent = round(fig91ab$pcent, 2)

# Order for x-axis
jOrder = c('John Paul Stevens',
           'Elena Kagan',
           'Antonin Scalia',
           'Neil M. Gorsuch',
           'David H. Souter',
           'Stephen G. Breyer',
           'Sonia M. Sotomayor',
           'Samuel A. Alito',
           'Clarence Thomas',
           "Sandra Day O'Connor",
           'Anthony M. Kennedy',
           'John G. Roberts',
           'Ruth Bader Ginsburg',
           'William H. Rehnquist')
fig91ab$justiceRealName = factor(fig91ab$justiceRealName, levels = jOrder)

# Plot
ggplot(subset(fig91ab, speechType == 'Oral Argument'), aes(x = justiceRealName, y = pcent, fill = variable)) +
  geom_bar(stat = "identity", position = position_dodge(width = 1)) +
  labs(x = "Justices", y = "Percent of Public Speech") +
  scale_y_continuous(breaks = seq(0, 20, by = 1)) +
  scale_fill_manual(labels=c('sumFem' = 'Feminine Language',
                             'sumMas' = 'Masculine Language',
                             'sumAffect' = 'Emotional Language',
                             'sumPolitic' = "Political Language",
                             'sumCognition' = 'Cognitive Language',
                             'sumDrive' = "Drives"),
                    name = 'Linguistic\nContent',
                    values = c('sumFem' = 'black',
                               'sumMas' = 'grey80',
                               'sumAffect' = 'grey68',
                               'sumPolitic' = 'grey15',
                               'sumCognition' = 'grey55',
                               'sumDrive' = 'grey35')) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1, size=13),
        axis.text.y = element_text(hjust = 1, size=14),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        strip.text = element_text(size = 16),
        legend.text = element_text(size = 8),
        legend.title = element_text(size = 8),
        legend.position = "top", legend.justification = "right") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.1b
###

ggplot(subset(fig91ab, speechType == 'Public Remarks'), aes(x = justiceRealName, y = pcent, fill = variable)) +
  geom_bar(stat = "identity", position = position_dodge(width = 1)) +
  labs(x = "Justices", y = "Percent of Public Speech") +
  scale_y_continuous(breaks = seq(0, 20, by = 1)) +
  scale_fill_manual(labels=c('sumFem' = 'Feminine Language',
                             'sumMas' = 'Masculine Language',
                             'sumAffect' = 'Emotional Language',
                             'sumPolitic' = "Political Language",
                             'sumCognition' = 'Cognitive Language',
                             'sumDrive' = "Drives"),
                    name = 'Linguistic\nContent',
                    values = c('sumFem' = 'black',
                               'sumMas' = 'grey80',
                               'sumAffect' = 'grey68',
                               'sumPolitic' = 'grey15',
                               'sumCognition' = 'grey55',
                               'sumDrive' = 'grey35')) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1, size=13),
        axis.text.y = element_text(hjust = 1, size=14),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        strip.text = element_text(size = 16),
        legend.text = element_text(size = 8),
        legend.title = element_text(size = 8),
        legend.position = "top", legend.justification = "right") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.4
###

# Subset data
fig94 = subset(df, select = c(audienceType, justiceName))

# Sums per audience type
fig94 = fig94 %>%
  group_by(justiceName, audienceType) %>%
  mutate(sumLegal = sum(audienceType == 'legal'), 
         sumNonLegal = sum(audienceType == 'nonLegal')) 
fig94 = unique(fig94)

# Sort data
fig94 = melt(fig94, id.vars = c("justiceName", "audienceType"))

# Modify names and subset
fig94$audienceType[fig94$audienceType == 'legal'] = 'Legal'
fig94$audienceType[fig94$audienceType =='nonLegal'] = 'Non-legal'
fig94 = subset(fig94, audienceType %in% c('Legal', "Non-legal") & value > 0)

# Add the justices' full names for plotting
fig94$justiceRealName = fig94$justiceName
fig94$justiceRealName[fig94$justiceRealName == 'JGRoberts'] = 'John G. Roberts'
fig94$justiceRealName[fig94$justiceRealName == 'RBGinsburg'] = 'Ruth Bader Ginsburg'
fig94$justiceRealName[fig94$justiceRealName == 'SGBreyer'] = 'Stephen G. Breyer'
fig94$justiceRealName[fig94$justiceRealName == "SDOConnor"] = "Sandra Day O'Connor"
fig94$justiceRealName[fig94$justiceRealName == 'CThomas'] = 'Clarence Thomas'
fig94$justiceRealName[fig94$justiceRealName == 'AScalia'] = 'Antonin Scalia'
fig94$justiceRealName[fig94$justiceRealName == 'AMKennedy'] = 'Anthony M. Kennedy'
fig94$justiceRealName[fig94$justiceRealName =='EKagan'] = 'Elena Kagan'
fig94$justiceRealName[fig94$justiceRealName == 'SAAlito'] = 'Samuel A. Alito'
fig94$justiceRealName[fig94$justiceRealName == 'SMSotomayor'] = 'Sonia M. Sotomayor'
fig94$justiceRealName[fig94$justiceRealName == 'JPStevens'] = 'John Paul Stevens'
fig94$justiceRealName[fig94$justiceRealName == 'WHRehnquist'] = 'William H. Rehnquist'
fig94$justiceRealName[fig94$justiceRealName == 'DHSouter'] = 'David H. Souter'
fig94$justiceRealName[fig94$justiceRealName =='NMGorsuch'] = 'Neil M. Gorsuch'
jOrder = c('John G. Roberts',
           'Ruth Bader Ginsburg',
           'Stephen G. Breyer',
           "Sandra Day O'Connor",
           'Clarence Thomas',
           'Antonin Scalia',
           'Anthony M. Kennedy',
           'Elena Kagan',
           'Samuel A. Alito',
           'Sonia M. Sotomayor',
           'John Paul Stevens',
           'William H. Rehnquist',
           'David H. Souter',
           'Neil M. Gorsuch')
fig94$justiceRealName = factor(fig94$justiceRealName, levels = jOrder)

# Plot
ggplot(fig94, aes(x = justiceRealName, y = value, fill = variable)) +
  geom_histogram(stat = "identity") +
  labs(x = "Justices", y = "Frequency") +
  scale_fill_grey(labels = c('sumLegal' = "Legal Audience",
                             'sumNonLegal' = 'Non-Legal Audience'),
                  name = "Audience Type") +
  scale_y_continuous(breaks = seq(0, 60, by = 2)) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, size=14, vjust = 0.3, hjust = 1),
        axis.text.y = element_text(hjust = 1, size=14),
        axis.title.x = element_text(size = 16),
        axis.title.y = element_text(size = 16),
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        legend.position = 'top', legend.justification = 'right') +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))


###
### Figure 9.5a
###

audMod_df = subset(mod_df, term == 'audienceTypelegal')
audMod_df = subset(audMod_df, justiceRealName != 'John Paul Stevens')

ggplot(subset(audMod_df, outcome == "Feminine Language"), aes(x = reorder(justiceRealName, estimate), 
                                                   y = estimate,
                                                   color = sig)) +  # Map 'sig' to color
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), size = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) + # makes justice names bigger
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14), # changes size of each item in the legend
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.5b
###

ggplot(subset(audMod_df, outcome == "Masculine Language"), aes(x = reorder(justiceRealName, estimate), 
                                                              y = estimate,
                                                              color = sig)) +  # Map 'sig' to color
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), size = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) + # makes justice names bigger
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14), # changes size of each item in the legend
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))


###
### Figure 9.6a (top)
###

ggplot(subset(audMod_df, outcome == "Emotional Language"), aes(x = reorder(justiceRealName, estimate), 
                              y = estimate,
                              color = sig)) +  # Map 'sig' to color
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), size = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) + # makes justice names bigger
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14), # changes size of each item in the legend
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))


###
### Figure 9.6a (bottom)
###

ggplot(subset(audMod_df, outcome == "Drives"), aes(x = reorder(justiceRealName, estimate), 
                                                               y = estimate,
                                                               color = sig)) +  # Map 'sig' to color
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), size = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) + # makes justice names bigger
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14), # changes size of each item in the legend
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.6b (top)
###

ggplot(subset(audMod_df, outcome == "Cognitive Language"), aes(x = reorder(justiceRealName, estimate), 
                                                   y = estimate,
                                                   color = sig)) +  # Map 'sig' to color
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), size = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) + # makes justice names bigger
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14), # changes size of each item in the legend
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))



###
### Figure 9.6b (bottom)
###

ggplot(subset(audMod_df, outcome == "Political Language"), aes(x = reorder(justiceRealName, estimate), 
                                                               y = estimate,
                                                               color = sig)) +  # Map 'sig' to color
  geom_point(position = position_dodge(width = 0.4), size = 3.5) +
  geom_errorbar(aes(ymin=lower, ymax=upper), width=0, position = position_dodge(width = 0.4), size = 1) +
  geom_hline(yintercept=0, linetype=2) +
  scale_color_manual(values = c("gray", "black"),
                     labels=c('True', 'False'),
                     name='95% Confidence Interval Includes Zero') +
  theme_minimal() +
  coord_flip() +
  labs(y = NULL,
       x = NULL) +
  facet_wrap(~outcome, scales = 'free_x')+
  theme(legend.position = 'bottom') +
  theme(axis.text.y = element_text(size = 14, vjust = 0.3)) + # makes justice names bigger
  theme(strip.text = element_text(size = 16),
        legend.text = element_text(size = 14), # changes size of each item in the legend
        legend.title = element_text(size = 14),
        axis.title.x = element_text(size = 14),
        axis.text.x = element_text(size=14)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))

#####################
#####################
#####################
### END CODE USED ###
#####################
#####################
#####################
